package com.sct.marketing

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { SCTApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SCTApp() {
    val context = LocalContext.current
    var title by remember { mutableStateOf("Promo Jasa Service AC") }
    var message by remember {
        mutableStateOf("SURYA COOL TEKNIK\nJasa service dan cuci AC.\nHubungi kami untuk informasi dan pemesanan.\n\n#SuryaCoolTeknik #ServiceAC")
    }
    var status by remember { mutableStateOf("Siapkan materi iklan, lalu pilih cara publikasi.") }

    fun shareText() {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, "$title\n\n$message")
        }
        context.startActivity(Intent.createChooser(intent, "Bagikan iklan SCT"))
        status = "Menu berbagi Android dibuka. Pilih aplikasi tujuan dan tinjau sebelum mengirim."
    }

    fun openWebsite() {
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com"))
        context.startActivity(intent)
        status = "Browser dibuka. Pilih website tujuan dan publikasikan sesuai aturan situs."
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = androidx.compose.ui.graphics.Color(0xFF123B5D))) {
        Scaffold(
            topBar = {
                TopAppBar(title = {
                    Column {
                        Text("SCT MARKETING CENTER", fontWeight = FontWeight.Bold)
                        Text("SURYA COOL TEKNIK", style = MaterialTheme.typography.labelSmall)
                    }
                })
            }
        ) { padding ->
            Column(
                modifier = Modifier.padding(padding).fillMaxSize()
                    .verticalScroll(rememberScrollState()).padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primary)) {
                    Column(Modifier.padding(18.dp)) {
                        Text("Pusat Promosi Digital", color = androidx.compose.ui.graphics.Color.White,
                            style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                        Text("Buat satu materi, lalu bagikan ke kanal pilihanmu.",
                            color = androidx.compose.ui.graphics.Color.White)
                    }
                }
                Text("Judul iklan", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(value = title, onValueChange = { title = it },
                    modifier = Modifier.fillMaxWidth(), singleLine = true)
                Text("Isi materi promosi", fontWeight = FontWeight.SemiBold)
                OutlinedTextField(value = message, onValueChange = { message = it },
                    modifier = Modifier.fillMaxWidth().heightIn(min = 170.dp))
                Button(onClick = { shareText() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Bagikan iklan")
                }
                Text("Publikasi melalui platform", fontWeight = FontWeight.Bold)
                Text("Pilih platform dari menu berbagi Android. Ketersediaan publikasi tergantung aplikasi, jenis akun, dan izin platform.")
                OutlinedButton(onClick = { shareText() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Facebook / Instagram / TikTok")
                }
                OutlinedButton(onClick = { shareText() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Google Business")
                }
                OutlinedButton(onClick = { openWebsite() }, modifier = Modifier.fillMaxWidth()) {
                    Text("Buka website melalui browser")
                }
                Card {
                    Column(Modifier.padding(14.dp)) {
                        Text("Status", fontWeight = FontWeight.Bold)
                        Text(status)
                    }
                }
                Text("Catatan: aplikasi ini membantu menyiapkan dan membagikan konten. Publikasi otomatis memerlukan integrasi API resmi dan izin akun masing-masing platform.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
